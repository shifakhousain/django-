from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('clothes/', views.clothes, name='clothes'),
    path('watches/', views.watches, name='watches'),
    path('electronics/', views.electronics, name='electronics'),
    path('about/', views.about, name='about'),
]

