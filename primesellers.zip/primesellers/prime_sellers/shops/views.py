from django.shortcuts import render

def home(request):
    return render(request, 'index.html')

def clothes(request):
    return render(request, 'clothes.html')

def watches(request):
    return render(request, 'watches.html')

def electronics(request):
    return render(request, 'electronics.html')

def about(request):
    return render(request, 'about.html')

